-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 16, 2022 at 11:40 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `paraiso`
--

-- --------------------------------------------------------

--
-- Table structure for table `favorites`
--

CREATE TABLE `favorites` (
  `user_id` int(11) DEFAULT NULL,
  `wishlist_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `favorites`
--

INSERT INTO `favorites` (`user_id`, `wishlist_id`) VALUES
(1, 3),
(6, 4),
(7, 5),
(2, 6);

-- --------------------------------------------------------

--
-- Table structure for table `favorites_entry`
--

CREATE TABLE `favorites_entry` (
  `wishlist_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `favorites_entry`
--

INSERT INTO `favorites_entry` (`wishlist_id`, `product_id`) VALUES
(3, 6),
(4, 3),
(4, 6),
(5, 8),
(6, 7);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `product_name` varchar(50) NOT NULL,
  `product_image` varchar(100) NOT NULL,
  `product_price` double NOT NULL,
  `product_category` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `product_name`, `product_image`, `product_price`, `product_category`) VALUES
(1, 'Aloe Vera', 'views/photos/aloe.jpg', 10, 'Succulent'),
(2, 'Monstera Borsigiana', 'views/photos/borsigiana1.jpg', 23.4, 'Monstera'),
(3, 'Opuntia microdasys', 'views/photos/opuntia.jpg', 7.99, 'Succulent'),
(4, 'Alocasia cucullata', 'views/photos/cucullata1.jpg', 18, 'Alocasia'),
(5, 'Fairy Castle Cactus', 'views/photos/fairy.jpg', 4.55, 'Succulent'),
(6, 'Marble Queen Pothos', 'views/photos/Marble-Queen-Pothos1.jpg', 27.12, 'Pothos'),
(7, 'Yucca Palm', 'views/photos/yucca.jpg', 48.3, 'Palm tree'),
(8, 'Red-headed Irishman', 'views/photos/irishman1.jpg', 9.99, 'Succulent'),
(9, 'Monstera Deliciosa', 'views/photos/627f8a8a75098.jpg', 23.99, 'Monstera');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `age` int(11) NOT NULL,
  `role` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `age`, `role`, `created_at`) VALUES
(1, 'Aurora', 'aurora@teddy.sk', '$argon2id$v=19$m=65536,t=4,p=1$M0VtWGJLOFZJeWVqei5xcg$d6thp+fLL/Jvvx6dymvGDnRNE6wXpP0x7DsmwHkJTGE', 10, 0, '2022-05-16 02:09:48'),
(2, 'Admin', 'admin@admin.com', '$argon2id$v=19$m=65536,t=4,p=1$Ljk3N05QMmNxTkJvZ3FzSw$YVXg8FrEaMCVr7WSQFBf3IlGV4RuIpD6+ZMTuG1qRbk', 43, 1, '2022-05-16 02:12:54'),
(3, 'Teddy', 'teddypark@aurora.com', '$argon2id$v=19$m=65536,t=4,p=1$a3dBcmpoT3ExQm0vR2VNZg$x2zVwe8cN6kDZqMLscLhqbwwiDqxIBgNiyDmtc16cvo', 11, 0, '2022-05-16 02:13:40'),
(4, 'Nikola', 'njanickova8@gmail.com', '$argon2id$v=19$m=65536,t=4,p=1$WUt6N1pRejRSclNRZ2gwSg$UdCztrtMrSptxJS7+gpJUDbd3atI8nmTbm0vAopbW0o', 65, 0, '2022-05-16 02:14:05'),
(5, 'Dominko', 'dodko@cheche.lol', '$argon2id$v=19$m=65536,t=4,p=1$U0Y5R096UTM5N1RvYkE0Vw$heTGghMb670HoU0kNwbcsIsTukfi4LpFEpsHcHWcwhY', 76, 0, '2022-05-16 02:14:41'),
(6, 'Riso', 'uybh@gmail.com', '$argon2id$v=19$m=65536,t=4,p=1$QlhWbXFWQktTVlBlMHlkdQ$5/ylTglXt19rIQNhFbsqBRWS8p7OUSJI+vSQOx6gnCM', 5, 0, '2022-05-16 02:17:25'),
(7, 'Nikola', 'janickova26@stud.uniza.sk', '$argon2id$v=19$m=65536,t=4,p=1$UVRMWFJEdTdJa21PWlFYVA$faE410JbIUpoNjbjnuE2lBOZYLKYGmSCebQb6XQX6dM', 22, 0, '2022-05-16 09:26:46');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `favorites`
--
ALTER TABLE `favorites`
  ADD PRIMARY KEY (`wishlist_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `favorites`
--
ALTER TABLE `favorites`
  MODIFY `wishlist_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
